﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Web.Http;
using DemoAPI.Models;
using System.Threading.Tasks;
using Newtonsoft.Json;
using DemoAPI.Controllers;
using System.Web;
using System.IO;

namespace DemoAPI.Controllers
{
    [RoutePrefix("api/Home")]
    public class HomeController : ApiController 
    {
        [HttpGet]
        public object TestConnection()
        {
            try
            {
                return "Successfully Tested " ;
            }
            catch (Exception)
            {
                return "Error";
            }
        }

        [HttpPost]
        public async Task<object> GenerateRandomUser(AuthenticationDetails AuthDetails)
        {
            List<string> customCredentials = new List<string>();
            try
            {
                string[] lines = File.ReadAllLines("D:\\Projects\\PublishedFolder\\TestAPI\\users.properties");
                foreach (string line in lines)
                    customCredentials.Add(line);
            }
            catch (Exception ex)
            {

            }

            try
            {
                System.Web.HttpContext ctg = HttpContext.Current;
                string[] header = ctg.Request.Headers.AllKeys;
                String headers = "";
                String Authn = ctg.Request.Headers.Get("Authorization");
                Authn = Authn.Replace("Basic ", "");
                String Authnplain = System.Text.Encoding.UTF8.GetString(System.Convert.FromBase64String(Authn));
                if (customCredentials.Contains(Authnplain))
                {
                    string Name = "";
                    var generator = new GeneratorController();
                    RandomUserDetails RandomUser = new RandomUserDetails();
                    PersonAPIResponse person = await generator.Generate();
                    foreach (var Results in person.Results)
                    {
                        Name = " " + Results.Name.First + " " + Results.Name.Last + " " + Results.Gender;
                    }
                    RandomUser.UserName = Name;
                    return RandomUser;
                }
                else
                {
                    return "Wrong Credentials. Try Again! ";
                }
                return " ";
            }
            catch (Exception)
            { 
                return " ";
            }
        }

        public class GeneratorController
        {
            public async Task<PersonAPIResponse> Generate()
            {
                using (var client = new HttpClient())
                {
                    try
                    {
                        client.BaseAddress = new Uri("https://api.randomuser.me");
                        var response = await client.GetAsync("https://api.randomuser.me");
                        response.EnsureSuccessStatusCode();
                        var stringResult = await response.Content.ReadAsStringAsync();
                        var rawData = JsonConvert.DeserializeObject<PersonAPIResponse>(stringResult);
                        return rawData;
                    }
                    catch (HttpRequestException httpRequestException)
                    {
                        throw new Exception($"Error generating person: {httpRequestException.Message}");
                    }
                }
            }
        }
       
        public class PersonAPIResponse
        {
            public IEnumerable<PersonDescription> Results { get; set; }
        }

        public class PersonDescription
        {
            public string Gender { get; set; }
            public Name Name { get; set; }
        }

        public class Name
        {
            public string Title { get; set; }
            public string First { get; set; }
            public string Last { get; set; }
        }

    }

}
