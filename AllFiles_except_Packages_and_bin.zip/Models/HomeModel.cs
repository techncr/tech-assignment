﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace DemoAPI.Models
{
    public class HomeModel
    {
    }
    
    public class AuthenticationDetails
    {
        [Required(ErrorMessage = "User ID is required.")]
        public string ID { get; set; }

        [Required(ErrorMessage = "Password is required.")]
        public string Password { get; set; }
    }

    public class RandomUserDetails
    {
        public string UserName { get; set; }
    }
}